import { User } from "../app/models/user";

export const Users: User[] = [
  {
    id: 1,
    name: "Pat",
    profile_pic_url:
      "https://i.guim.co.uk/img/static/sys-images/Arts/Arts_/Pictures/2009/2/20/1235150177056/Smiley-001.jpg?width=700&quality=85&auto=format&usm=12&fit=max&s=824b736eebe979d8f2bf41e4eaf09d20",
    bio: "Pat did a lot of good things in his life."
  },
  {
    id: 4,
    name: "Pam",
    profile_pic_url:
      "https://i.kym-cdn.com/entries/icons/facebook/000/017/931/ronald-mcdonald-profile.jpg",
    bio: "Pam did even greater things in her life."
  },
  {
    id: 5,
    name: "John",
    profile_pic_url:
      "https://m.media-amazon.com/images/M/MV5BMTAzMzgwNDgzODBeQTJeQWpwZ15BbWU4MDA2OTk2NDEx._V1_.jpg",
    bio: "John was a carpenter until he got into web development."
  },
  {
    id: 11,
    name: "Betty",
    profile_pic_url:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Betty_White_2010.jpg/220px-Betty_White_2010.jpg",
    bio: "Betty has played a lot of pranks of people."
  }
];
