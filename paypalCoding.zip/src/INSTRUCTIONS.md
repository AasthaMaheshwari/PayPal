# Expand this bootstrapped Angular application

1. Display a list of users
    * Users are available from /assets/mock-users.ts
2. When a user is clicked, display that user's information (picture, name, bio), in a "currently selected" element
3. Add an edit button to the currently selected element to allow editing/saving the bio.
4. Write unit tests for components.
