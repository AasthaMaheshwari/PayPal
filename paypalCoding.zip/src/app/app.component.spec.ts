import { async, ComponentFixture, TestBed } from '@angular/core/testing';



describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppComponent]
    })
      .compileComponents();
  }));

  

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  describe('ids',() =>{
    let expected = 'real value';
    beforeEach(async(() =>{
      it('id should be correct ', () => {
        expect('id').toBe('real value');
      });

    }));

  });

  describe('name', () => {
    let expected = 'string value';
    beforeEach(async(() => {
      it('name should be correct ', () => {
        expect('name').toBe('string value');
      });

    }));

  });

  describe('Profile_pic', () => {
    let expected = 'string value';
    beforeEach(async(() => {
      it('Profile_pic should be correct ', () => {
        expect('Profile_pic').toBe('string value');
      });

    }));

  });

  describe('bio', () => {
    let expected = 'string value';
    beforeEach(async(() => {
      it('bio should be correct ', () => {
        expect('bio').toBe('string value');
      });

    }));

  });
  
