import { Component, Input } from "@angular/core";
import { User } from "../app/models/user";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  @Input() user: User;
}
