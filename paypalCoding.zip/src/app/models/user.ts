export class User {
  id: number;
  name: string;
  profile_pic_url: string;
  bio: string;
}
